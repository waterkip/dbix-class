#   belongs to t/run/90ensure_class_loaded.tl
package # hide from PAUSE
    DBICTest::OptionalComponent;
use warnings;
use strict;

1;
