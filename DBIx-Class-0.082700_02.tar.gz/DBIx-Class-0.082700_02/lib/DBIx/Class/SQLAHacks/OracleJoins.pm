package # Hide from PAUSE
  DBIx::Class::SQLAHacks::OracleJoins;

use warnings;
use strict;

use base qw( DBIx::Class::SQLMaker::OracleJoins );

1;
